// main.c
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number>\n", argv[0]);
        return 1;
    }

    double number = atof(argv[1]);  // Convert input to double
    double result = sqrt(number);   // Compute the square root

    printf("The square root of %f is %f\n", number, result);
    return 0;
}

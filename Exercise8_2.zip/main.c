// main.c
#include <stdio.h>
#include "test.h"

#define NUMBER 10

int main() {
    printf("Davis Iceman\n");
    printf("test(%d) = %d\n", NUMBER, test(NUMBER));
    return 0;
}
